# dotnet_testes
Implementando sua stack de testes de unidade e integrados em um projeto .NET de Crowdfunding
